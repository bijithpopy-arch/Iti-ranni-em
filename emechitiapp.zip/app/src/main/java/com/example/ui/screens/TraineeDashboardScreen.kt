package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Logout
import androidx.compose.material.icons.automirrored.rounded.Send
import androidx.compose.material.icons.rounded.AccessTime
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Description
import androidx.compose.material.icons.rounded.ErrorOutline
import androidx.compose.material.icons.rounded.EventNote
import androidx.compose.material.icons.rounded.PictureAsPdf
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Sensors
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.AttendanceSummary
import com.example.data.TraineeLeaveItem
import com.example.ui.components.AttendanceStatusPill
import com.example.ui.components.DigitalSignaturePad
import com.example.ui.components.EspStatusBadge
import com.example.ui.components.ExternalUrlHelper
import com.example.ui.components.LeaveStatusBadge
import com.example.ui.components.TricolourRibbon
import com.example.ui.theme.JetBrainsMonoFamily
import com.example.ui.theme.LocalItiColors
import com.example.viewmodel.AppUiState

private val LEAVE_TYPES = listOf("1-Hour Permission", "Half-Day Leave")
private val QUICK_TIME_WINDOWS = listOf(
    "11:00 AM - 12:00 PM",
    "02:00 PM - 03:00 PM",
    "Afternoon Session",
    "Forenoon Session"
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TraineeDashboardScreen(
    uiState: AppUiState,
    onRefresh: () -> Unit,
    onLogout: () -> Unit,
    onSubmitLeave: (type: String, timeWindow: String, reason: String, studentSig: String, onSuccessReset: () -> Unit) -> Unit,
    onDismissFeedback: () -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler { onLogout() }

    val colors = LocalItiColors.current
    val context = LocalContext.current
    val data = uiState.traineeData

    var selectedType by remember { mutableStateOf(LEAVE_TYPES.first()) }
    var typeMenuExpanded by remember { mutableStateOf(false) }
    var timeWindow by remember { mutableStateOf("11:00 AM - 12:00 PM") }
    var reason by remember { mutableStateOf("") }
    var signature by remember { mutableStateOf("") }
    var sigResetKey by remember { mutableIntStateOf(0) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .statusBarsPadding()
            .navigationBarsPadding()
            .imePadding(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        TricolourRibbon(height = 3.dp)

        // Top App Bar
        Surface(
            color = colors.cardSurface,
            border = BorderStroke(1.dp, colors.borderSubtle),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = colors.skyContainer
                            ) {
                                Text(
                                    text = "ROLL #${data?.roll ?: uiState.activeRoll}",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontFamily = JetBrainsMonoFamily,
                                        fontWeight = FontWeight.Bold
                                    ),
                                    color = colors.skyAccent,
                                    modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp)
                                )
                            }
                            EspStatusBadge(label = stringResource(R.string.esp_badge_synced))
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Hello, ${data?.name ?: "Trainee"}",
                            style = MaterialTheme.typography.titleLarge,
                            color = MaterialTheme.colorScheme.onSurface,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        IconButton(
                            onClick = onRefresh,
                            enabled = !uiState.isRefreshingTrainee,
                            modifier = Modifier.testTag("trainee_refresh_button")
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Refresh,
                                contentDescription = stringResource(R.string.action_refresh),
                                tint = colors.skyAccent
                            )
                        }
                        IconButton(
                            onClick = onLogout,
                            modifier = Modifier.testTag("trainee_logout_button")
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Rounded.Logout,
                                contentDescription = stringResource(R.string.action_logout),
                                tint = colors.redAccent
                            )
                        }
                    }
                }
                if (uiState.isRefreshingTrainee) {
                    LinearProgressIndicator(
                        color = colors.skyAccent,
                        trackColor = colors.cardElevated,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }

        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .widthIn(max = 640.dp)
                .fillMaxWidth(),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            if (uiState.traineeBannerError != null) {
                item {
                    InlineAlertCard(
                        message = uiState.traineeBannerError,
                        isError = true
                    )
                }
            }

            if (data != null) {
                // 1. Today's Status Card
                item {
                    TodayStatusCard(attendance = data.attendance)
                }

                // 2. Attendance Percentage Ring & Breakdown Card
                item {
                    AttendancePercentageCard(attendance = data.attendance)
                }

                // 3. Apply for Out-Pass / Half-Day Leave Card
                item {
                    Surface(
                        shape = RoundedCornerShape(20.dp),
                        color = colors.cardSurface,
                        border = BorderStroke(1.dp, colors.borderSubtle),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(18.dp),
                            verticalArrangement = Arrangement.spacedBy(14.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clip(CircleShape)
                                        .background(colors.skyContainer),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Rounded.EventNote,
                                        contentDescription = null,
                                        tint = colors.skyAccent,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                                Column {
                                    Text(
                                        text = "Apply for Out-Pass / Half-Day Leave",
                                        style = MaterialTheme.typography.titleMedium,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    Text(
                                        text = "Digitally signed workflow via Instructor & Principal",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = colors.textMuted
                                    )
                                }
                            }

                            // Request Type Dropdown
                            ExposedDropdownMenuBox(
                                expanded = typeMenuExpanded,
                                onExpandedChange = { typeMenuExpanded = !typeMenuExpanded }
                            ) {
                                OutlinedTextField(
                                    value = selectedType,
                                    onValueChange = {},
                                    readOnly = true,
                                    label = { Text("Request Type") },
                                    trailingIcon = {
                                        ExposedDropdownMenuDefaults.TrailingIcon(expanded = typeMenuExpanded)
                                    },
                                    shape = RoundedCornerShape(12.dp),
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = colors.skyAccent,
                                        unfocusedBorderColor = colors.borderSubtle,
                                        focusedContainerColor = MaterialTheme.colorScheme.background,
                                        unfocusedContainerColor = MaterialTheme.colorScheme.background
                                    ),
                                    modifier = Modifier
                                        .menuAnchor()
                                        .fillMaxWidth()
                                        .testTag("leave_type_dropdown")
                                )
                                ExposedDropdownMenu(
                                    expanded = typeMenuExpanded,
                                    onDismissRequest = { typeMenuExpanded = false },
                                    modifier = Modifier.background(colors.cardElevated)
                                ) {
                                    LEAVE_TYPES.forEach { option ->
                                        DropdownMenuItem(
                                            text = { Text(option, color = MaterialTheme.colorScheme.onSurface) },
                                            onClick = {
                                                selectedType = option
                                                if (option == "Half-Day Leave" && timeWindow == "11:00 AM - 12:00 PM") {
                                                    timeWindow = "Afternoon Session"
                                                } else if (option == "1-Hour Permission" && timeWindow == "Afternoon Session") {
                                                    timeWindow = "11:00 AM - 12:00 PM"
                                                }
                                                typeMenuExpanded = false
                                            }
                                        )
                                    }
                                }
                            }

                            // Time Window Quick Chips + Input
                            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                LazyRow(
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    items(QUICK_TIME_WINDOWS) { preset ->
                                        FilterChip(
                                            selected = timeWindow == preset,
                                            onClick = { timeWindow = preset },
                                            label = {
                                                Text(
                                                    text = preset,
                                                    style = MaterialTheme.typography.labelSmall
                                                )
                                            },
                                            colors = FilterChipDefaults.filterChipColors(
                                                selectedContainerColor = colors.skyContainer,
                                                selectedLabelColor = colors.skyAccent,
                                                containerColor = MaterialTheme.colorScheme.background,
                                                labelColor = colors.textMuted
                                            ),
                                            border = FilterChipDefaults.filterChipBorder(
                                                enabled = true,
                                                selected = timeWindow == preset,
                                                borderColor = colors.borderSubtle,
                                                selectedBorderColor = colors.skyAccent
                                            )
                                        )
                                    }
                                }

                                OutlinedTextField(
                                    value = timeWindow,
                                    onValueChange = { timeWindow = it },
                                    label = { Text("Time Window") },
                                    placeholder = { Text("e.g., 11:00 AM - 12:00 PM or Afternoon Session") },
                                    leadingIcon = {
                                        Icon(
                                            imageVector = Icons.Rounded.AccessTime,
                                            contentDescription = null,
                                            tint = colors.skyAccent
                                        )
                                    },
                                    singleLine = true,
                                    shape = RoundedCornerShape(12.dp),
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = colors.skyAccent,
                                        unfocusedBorderColor = colors.borderSubtle,
                                        focusedContainerColor = MaterialTheme.colorScheme.background,
                                        unfocusedContainerColor = MaterialTheme.colorScheme.background
                                    ),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("leave_time_window_input")
                                )
                            }

                            // Reason Input
                            OutlinedTextField(
                                value = reason,
                                onValueChange = { reason = it },
                                label = { Text("Reason") },
                                placeholder = { Text("Enter valid reason for permission / leave") },
                                minLines = 2,
                                maxLines = 4,
                                shape = RoundedCornerShape(12.dp),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = colors.skyAccent,
                                    unfocusedBorderColor = colors.borderSubtle,
                                    focusedContainerColor = MaterialTheme.colorScheme.background,
                                    unfocusedContainerColor = MaterialTheme.colorScheme.background
                                ),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("leave_reason_input")
                            )

                            // Digital Signature Pad
                            DigitalSignaturePad(
                                defaultSignerName = data.name,
                                resetKey = sigResetKey,
                                onSignatureChanged = { signature = it },
                                title = "Trainee Digital Signature",
                                tagPrefix = "trainee_sig"
                            )

                            // Success / Error Feedback
                            AnimatedVisibility(visible = uiState.leaveSubmitMessage != null) {
                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    color = colors.emeraldContainer,
                                    border = BorderStroke(1.dp, colors.emeraldAccent.copy(alpha = 0.6f)),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("leave_submit_success_banner")
                                ) {
                                    Row(
                                        modifier = Modifier.padding(12.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Row(
                                            modifier = Modifier.weight(1f),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Rounded.CheckCircle,
                                                contentDescription = null,
                                                tint = colors.emeraldAccent
                                            )
                                            Column {
                                                if (!uiState.leaveSubmitReqId.isNullOrBlank()) {
                                                    Text(
                                                        text = "Request ID: ${uiState.leaveSubmitReqId}",
                                                        style = MaterialTheme.typography.labelLarge.copy(
                                                            fontFamily = JetBrainsMonoFamily,
                                                            fontWeight = FontWeight.Bold
                                                        ),
                                                        color = colors.emeraldAccent
                                                    )
                                                }
                                                Text(
                                                    text = uiState.leaveSubmitMessage.orEmpty(),
                                                    style = MaterialTheme.typography.bodySmall,
                                                    color = MaterialTheme.colorScheme.onSurface
                                                )
                                            }
                                        }
                                        IconButton(onClick = onDismissFeedback) {
                                            Icon(
                                                imageVector = Icons.Rounded.Close,
                                                contentDescription = "Dismiss",
                                                tint = colors.textMuted,
                                                modifier = Modifier.size(18.dp)
                                            )
                                        }
                                    }
                                }
                            }

                            AnimatedVisibility(visible = uiState.leaveSubmitError != null) {
                                InlineAlertCard(
                                    message = uiState.leaveSubmitError.orEmpty(),
                                    isError = true
                                )
                            }

                            // Submit Button
                            Button(
                                onClick = {
                                    onSubmitLeave(selectedType, timeWindow, reason, signature) {
                                        reason = ""
                                        signature = ""
                                        sigResetKey++
                                    }
                                },
                                enabled = !uiState.isSubmittingLeave,
                                shape = RoundedCornerShape(14.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = colors.emeraldAccent,
                                    contentColor = MaterialTheme.colorScheme.onSecondary
                                ),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(52.dp)
                                    .testTag("submit_leave_button")
                            ) {
                                if (uiState.isSubmittingLeave) {
                                    CircularProgressIndicator(
                                        color = MaterialTheme.colorScheme.onSecondary,
                                        strokeWidth = 2.5.dp,
                                        modifier = Modifier.size(20.dp)
                                    )
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Text("Submitting Request...")
                                } else {
                                    Icon(
                                        imageVector = Icons.AutoMirrored.Rounded.Send,
                                        contentDescription = null,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = "Submit Signed Out-Pass Request",
                                        style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold)
                                    )
                                }
                            }
                        }
                    }
                }

                // 4. My Leave & Pass History Header
                item {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "My Leave & Pass History",
                            style = MaterialTheme.typography.titleLarge,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "${data.leaves.size} record(s)",
                            style = MaterialTheme.typography.labelMedium.copy(fontFamily = JetBrainsMonoFamily),
                            color = colors.textMuted
                        )
                    }
                }

                if (data.leaves.isEmpty()) {
                    item {
                        Surface(
                            shape = RoundedCornerShape(18.dp),
                            color = colors.cardSurface,
                            border = BorderStroke(1.dp, colors.borderSubtle),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(28.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Description,
                                    contentDescription = null,
                                    tint = colors.textMuted,
                                    modifier = Modifier.size(36.dp)
                                )
                                Text(
                                    text = "No Out-Pass or Leave Requests Yet",
                                    style = MaterialTheme.typography.titleSmall,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = "Submitted requests and approved signed PDFs will appear here.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = colors.textMuted
                                )
                            }
                        }
                    }
                } else {
                    items(data.leaves, key = { it.id.ifBlank { "${it.date}_${it.type}_${it.hashCode()}" } }) { item ->
                        TraineeLeaveHistoryCard(
                            item = item,
                            onOpenPdf = { url -> ExternalUrlHelper.openUrl(context, url) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun TodayStatusCard(attendance: AttendanceSummary) {
    val colors = LocalItiColors.current
    Surface(
        shape = RoundedCornerShape(20.dp),
        color = colors.cardSurface,
        border = BorderStroke(1.dp, colors.borderSubtle),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("today_status_card")
    ) {
        Column(
            modifier = Modifier.padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Text(
                        text = "Today's Status",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = stringResource(R.string.esp_badge_live),
                        style = MaterialTheme.typography.labelSmall.copy(fontFamily = JetBrainsMonoFamily),
                        color = colors.emeraldAccent
                    )
                }
                AttendanceStatusPill(status = attendance.todayStatus)
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                EspTimeTile(
                    label = "ESP IN TIME",
                    timeValue = attendance.inT,
                    accentColor = colors.emeraldAccent,
                    modifier = Modifier.weight(1f)
                )
                EspTimeTile(
                    label = "ESP OUT TIME",
                    timeValue = attendance.outT,
                    accentColor = colors.amberAccent,
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}

@Composable
private fun EspTimeTile(
    label: String,
    timeValue: String,
    accentColor: Color,
    modifier: Modifier = Modifier
) {
    val colors = LocalItiColors.current
    Surface(
        shape = RoundedCornerShape(14.dp),
        color = MaterialTheme.colorScheme.background,
        border = BorderStroke(1.dp, colors.borderSubtle),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Icon(
                    imageVector = Icons.Rounded.Sensors,
                    contentDescription = null,
                    tint = accentColor,
                    modifier = Modifier.size(14.dp)
                )
                Text(
                    text = label,
                    style = MaterialTheme.typography.labelSmall.copy(fontFamily = JetBrainsMonoFamily),
                    color = colors.textMuted
                )
            }
            Text(
                text = timeValue.ifBlank { "-" },
                style = MaterialTheme.typography.titleLarge.copy(
                    fontFamily = JetBrainsMonoFamily,
                    fontWeight = FontWeight.Bold
                ),
                color = MaterialTheme.colorScheme.onSurface
            )
        }
    }
}

@Composable
private fun AttendancePercentageCard(attendance: AttendanceSummary) {
    val colors = LocalItiColors.current
    val pctClamped = attendance.pct.coerceIn(0, 100)
    val animatedSweep by animateFloatAsState(
        targetValue = (pctClamped / 100f) * 360f,
        animationSpec = tween(durationMillis = 850),
        label = "attendance_ring_sweep"
    )

    val ringColors = when {
        pctClamped >= 80 -> listOf(colors.skyAccent, colors.emeraldAccent)
        pctClamped >= 75 -> listOf(colors.amberAccent, colors.skyAccent)
        else -> listOf(colors.redAccent, colors.amberAccent)
    }

    val statusHint = when {
        pctClamped >= 80 -> "On Track (DGT >= 80% Eligibility)"
        pctClamped >= 75 -> "Borderline — Maintain Daily Swipes"
        else -> "Below 75% — Attention Required"
    }

    Surface(
        shape = RoundedCornerShape(20.dp),
        color = colors.cardSurface,
        border = BorderStroke(1.dp, colors.borderSubtle),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("attendance_percentage_card")
    ) {
        Column(
            modifier = Modifier.padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(18.dp)
            ) {
                // Circular Progress Ring
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier.size(116.dp)
                ) {
                    val trackColor = colors.borderSubtle
                    Canvas(modifier = Modifier.fillMaxSize().padding(6.dp)) {
                        drawArc(
                            color = trackColor,
                            startAngle = -90f,
                            sweepAngle = 360f,
                            useCenter = false,
                            style = Stroke(width = 11.dp.toPx(), cap = StrokeCap.Round)
                        )
                        drawArc(
                            brush = Brush.sweepGradient(colors = ringColors),
                            startAngle = -90f,
                            sweepAngle = animatedSweep,
                            useCenter = false,
                            style = Stroke(width = 11.dp.toPx(), cap = StrokeCap.Round)
                        )
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "${attendance.pct}%",
                            style = MaterialTheme.typography.headlineMedium.copy(
                                fontFamily = JetBrainsMonoFamily,
                                fontWeight = FontWeight.Bold
                            ),
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "OVERALL",
                            style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.5.sp),
                            color = colors.textMuted
                        )
                    }
                }

                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "Attendance Summary",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = statusHint,
                        style = MaterialTheme.typography.bodySmall,
                        color = if (pctClamped >= 80) colors.emeraldAccent else if (pctClamped >= 75) colors.amberAccent else colors.redAccent
                    )
                    LinearProgressIndicator(
                        progress = { pctClamped / 100f },
                        color = ringColors.first(),
                        trackColor = colors.borderSubtle,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(7.dp)
                            .clip(RoundedCornerShape(50))
                    )
                }
            }

            // Breakdown counters
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                MetricCounterTile(
                    label = "Present",
                    value = attendance.present.toString(),
                    accent = colors.emeraldAccent,
                    modifier = Modifier.weight(1f)
                )
                MetricCounterTile(
                    label = "Half-Day",
                    value = attendance.half.toString(),
                    accent = colors.amberAccent,
                    modifier = Modifier.weight(1f)
                )
                MetricCounterTile(
                    label = "Total Days",
                    value = attendance.total.toString(),
                    accent = colors.skyAccent,
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}

@Composable
private fun MetricCounterTile(
    label: String,
    value: String,
    accent: Color,
    modifier: Modifier = Modifier
) {
    val colors = LocalItiColors.current
    Surface(
        shape = RoundedCornerShape(14.dp),
        color = MaterialTheme.colorScheme.background,
        border = BorderStroke(1.dp, colors.borderSubtle),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(vertical = 12.dp, horizontal = 10.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Text(
                text = value,
                style = MaterialTheme.typography.headlineSmall.copy(
                    fontFamily = JetBrainsMonoFamily,
                    fontWeight = FontWeight.Bold
                ),
                color = accent
            )
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                color = colors.textMuted,
                maxLines = 1
            )
        }
    }
}

@Composable
private fun TraineeLeaveHistoryCard(
    item: TraineeLeaveItem,
    onOpenPdf: (String) -> Unit
) {
    val colors = LocalItiColors.current
    Surface(
        shape = RoundedCornerShape(18.dp),
        color = colors.cardSurface,
        border = BorderStroke(1.dp, colors.borderSubtle),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("leave_history_card_${item.id}")
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = item.id.ifBlank { "REQ" },
                    style = MaterialTheme.typography.labelLarge.copy(
                        fontFamily = JetBrainsMonoFamily,
                        fontWeight = FontWeight.Bold
                    ),
                    color = colors.skyAccent
                )
                LeaveStatusBadge(status = item.status)
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = item.type,
                    style = MaterialTheme.typography.titleSmall,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = item.date,
                    style = MaterialTheme.typography.bodySmall.copy(fontFamily = JetBrainsMonoFamily),
                    color = colors.textMuted
                )
            }

            if (item.pdf.isNotBlank()) {
                Button(
                    onClick = { onOpenPdf(item.pdf) },
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = colors.emeraldContainer,
                        contentColor = colors.emeraldAccent
                    ),
                    border = BorderStroke(1.dp, colors.emeraldAccent.copy(alpha = 0.55f)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("view_pdf_button_${item.id}")
                ) {
                    Icon(
                        imageVector = Icons.Rounded.PictureAsPdf,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "View Signed PDF",
                        style = MaterialTheme.typography.labelLarge
                    )
                }
            }
        }
    }
}

@Composable
internal fun InlineAlertCard(
    message: String,
    isError: Boolean,
    modifier: Modifier = Modifier
) {
    val colors = LocalItiColors.current
    val bg = if (isError) colors.redContainer else colors.emeraldContainer
    val fg = if (isError) colors.redAccent else colors.emeraldAccent
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = bg,
        border = BorderStroke(1.dp, fg.copy(alpha = 0.5f)),
        modifier = modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Icon(
                imageVector = if (isError) Icons.Rounded.ErrorOutline else Icons.Rounded.CheckCircle,
                contentDescription = null,
                tint = fg,
                modifier = Modifier.size(20.dp)
            )
            Text(
                text = message,
                style = MaterialTheme.typography.bodySmall,
                color = fg
            )
        }
    }
}

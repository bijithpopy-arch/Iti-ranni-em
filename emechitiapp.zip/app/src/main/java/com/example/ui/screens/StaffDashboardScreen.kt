package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.FactCheck
import androidx.compose.material.icons.automirrored.rounded.Logout
import androidx.compose.material.icons.outlined.Groups
import androidx.compose.material.icons.outlined.Memory
import androidx.compose.material.icons.outlined.PendingActions
import androidx.compose.material.icons.rounded.Groups
import androidx.compose.material.icons.rounded.Memory
import androidx.compose.material.icons.rounded.PendingActions
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.StaffTab
import com.example.data.UserRole
import com.example.ui.components.EspStatusBadge
import com.example.ui.components.ExternalUrlHelper
import com.example.ui.components.TricolourRibbon
import com.example.ui.theme.JetBrainsMonoFamily
import com.example.ui.theme.LocalItiColors
import com.example.viewmodel.AppUiState

@Composable
fun StaffDashboardScreen(
    uiState: AppUiState,
    onTabSelected: (StaffTab) -> Unit,
    onRefresh: () -> Unit,
    onLogout: () -> Unit,
    onApproveAndSign: (reqId: String, signature: String) -> Unit,
    onDismissApprovalFeedback: () -> Unit,
    onRegisterSearchChanged: (String) -> Unit,
    onRegisterStatusFilterChanged: (String) -> Unit,
    onExportPdf: (onPdfReady: (String) -> Unit) -> Unit,
    onEspRollChanged: (String) -> Unit,
    onTriggerManualTap: () -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler {
        if (uiState.selectedStaffTab != StaffTab.PENDING_APPROVALS) {
            onTabSelected(StaffTab.PENDING_APPROVALS)
        } else {
            onLogout()
        }
    }

    val colors = LocalItiColors.current
    val context = LocalContext.current
    val pendingCount = uiState.staffData?.pendingLeaves?.size ?: 0
    val allAttendance = uiState.staffData?.allAttendance.orEmpty()
    val presentTodayCount = allAttendance.count {
        val status = it.todayStatus.uppercase()
        status == "PRESENT" || status.contains("HALF") || status.contains("OUT-PASS")
    }

    BoxWithConstraints(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        val useRail = maxWidth >= 680.dp

        Scaffold(
            containerColor = MaterialTheme.colorScheme.background,
            contentWindowInsets = WindowInsets(0, 0, 0, 0),
            topBar = {
                StaffHeaderBar(
                    role = uiState.activeStaffRole,
                    totalTrainees = allAttendance.size,
                    presentToday = presentTodayCount,
                    pendingApprovals = pendingCount,
                    isRefreshing = uiState.isRefreshingStaff,
                    onRefresh = onRefresh,
                    onLogout = onLogout
                )
            },
            bottomBar = {
                if (!useRail) {
                    NavigationBar(
                        containerColor = colors.cardSurface,
                        contentColor = MaterialTheme.colorScheme.onSurface,
                        windowInsets = WindowInsets.navigationBars
                    ) {
                        StaffTab.entries.forEach { tab ->
                            val selected = uiState.selectedStaffTab == tab
                            NavigationBarItem(
                                selected = selected,
                                onClick = { onTabSelected(tab) },
                                icon = {
                                    StaffTabIcon(
                                        tab = tab,
                                        selected = selected,
                                        pendingCount = pendingCount
                                    )
                                },
                                label = {
                                    Text(
                                        text = tab.label,
                                        style = MaterialTheme.typography.labelSmall,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = colors.skyAccent,
                                    selectedTextColor = colors.skyAccent,
                                    indicatorColor = colors.skyContainer,
                                    unselectedIconColor = colors.textMuted,
                                    unselectedTextColor = colors.textMuted
                                ),
                                modifier = Modifier.testTag("staff_nav_${tab.name.lowercase()}")
                            )
                        }
                    }
                }
            }
        ) { innerPadding ->
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                if (useRail) {
                    NavigationRail(
                        containerColor = colors.cardSurface,
                        contentColor = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.fillMaxHeight()
                    ) {
                        Spacer(modifier = Modifier.height(12.dp))
                        StaffTab.entries.forEach { tab ->
                            val selected = uiState.selectedStaffTab == tab
                            NavigationRailItem(
                                selected = selected,
                                onClick = { onTabSelected(tab) },
                                icon = {
                                    StaffTabIcon(
                                        tab = tab,
                                        selected = selected,
                                        pendingCount = pendingCount
                                    )
                                },
                                label = {
                                    Text(
                                        text = tab.label,
                                        style = MaterialTheme.typography.labelSmall
                                    )
                                },
                                colors = NavigationRailItemDefaults.colors(
                                    selectedIconColor = colors.skyAccent,
                                    selectedTextColor = colors.skyAccent,
                                    indicatorColor = colors.skyContainer,
                                    unselectedIconColor = colors.textMuted,
                                    unselectedTextColor = colors.textMuted
                                ),
                                modifier = Modifier.testTag("staff_rail_${tab.name.lowercase()}")
                            )
                        }
                    }
                }

                Column(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                ) {
                    if (uiState.staffBannerError != null) {
                        Box(modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
                            InlineAlertCard(message = uiState.staffBannerError, isError = true)
                        }
                    }

                    when (uiState.selectedStaffTab) {
                        StaffTab.PENDING_APPROVALS -> PendingApprovalsTab(
                            uiState = uiState,
                            onApproveAndSign = onApproveAndSign,
                            onDismissApprovalFeedback = onDismissApprovalFeedback
                        )

                        StaffTab.ATTENDANCE_REGISTER -> AttendanceRegisterTab(
                            uiState = uiState,
                            onSearchChanged = onRegisterSearchChanged,
                            onStatusFilterChanged = onRegisterStatusFilterChanged,
                            onExportPdf = {
                                onExportPdf { url ->
                                    ExternalUrlHelper.openUrl(context, url)
                                }
                            }
                        )

                        StaffTab.ESP_TERMINAL -> EspTerminalTab(
                            uiState = uiState,
                            onRollChanged = onEspRollChanged,
                            onTriggerManualTap = onTriggerManualTap
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun StaffHeaderBar(
    role: UserRole,
    totalTrainees: Int,
    presentToday: Int,
    pendingApprovals: Int,
    isRefreshing: Boolean,
    onRefresh: () -> Unit,
    onLogout: () -> Unit
) {
    val colors = LocalItiColors.current
    val roleTitle = if (role == UserRole.PRINCIPAL) {
        "Principal Dashboard"
    } else {
        "Trade Instructor Portal"
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(colors.cardSurface)
            .statusBarsPadding()
    ) {
        TricolourRibbon(height = 3.dp)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = roleTitle,
                    style = MaterialTheme.typography.titleLarge,
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(4.dp))
                EspStatusBadge(label = stringResource(R.string.esp_badge_live))
            }

            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                IconButton(
                    onClick = onRefresh,
                    enabled = !isRefreshing,
                    modifier = Modifier.testTag("staff_refresh_button")
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Refresh,
                        contentDescription = stringResource(R.string.action_refresh),
                        tint = colors.skyAccent
                    )
                }
                IconButton(
                    onClick = onLogout,
                    modifier = Modifier.testTag("staff_logout_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Rounded.Logout,
                        contentDescription = stringResource(R.string.action_logout),
                        tint = colors.redAccent
                    )
                }
            }
        }

        // Compact KPI Strip
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 16.dp, end = 16.dp, bottom = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            KpiMiniBadge(
                label = "Trainees",
                value = totalTrainees.toString(),
                accent = colors.skyAccent,
                modifier = Modifier.weight(1f)
            )
            KpiMiniBadge(
                label = "Active Today",
                value = presentToday.toString(),
                accent = colors.emeraldAccent,
                modifier = Modifier.weight(1f)
            )
            KpiMiniBadge(
                label = "Pending",
                value = pendingApprovals.toString(),
                accent = if (pendingApprovals > 0) colors.amberAccent else colors.textMuted,
                modifier = Modifier.weight(1f)
            )
        }

        if (isRefreshing) {
            LinearProgressIndicator(
                color = colors.skyAccent,
                trackColor = colors.cardElevated,
                modifier = Modifier.fillMaxWidth()
            )
        } else {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(1.dp)
                    .background(colors.borderSubtle)
            )
        }
    }
}

@Composable
private fun KpiMiniBadge(
    label: String,
    value: String,
    accent: Color,
    modifier: Modifier = Modifier
) {
    val colors = LocalItiColors.current
    Surface(
        shape = RoundedCornerShape(10.dp),
        color = MaterialTheme.colorScheme.background,
        border = BorderStroke(1.dp, colors.borderSubtle),
        modifier = modifier
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                color = colors.textMuted,
                maxLines = 1
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = value,
                style = MaterialTheme.typography.labelLarge.copy(
                    fontFamily = JetBrainsMonoFamily,
                    fontWeight = FontWeight.Bold
                ),
                color = accent
            )
        }
    }
}

@Composable
private fun StaffTabIcon(
    tab: StaffTab,
    selected: Boolean,
    pendingCount: Int
) {
    val colors = LocalItiColors.current
    val icon: ImageVector = when (tab) {
        StaffTab.PENDING_APPROVALS -> if (selected) Icons.Rounded.PendingActions else Icons.Outlined.PendingActions
        StaffTab.ATTENDANCE_REGISTER -> if (selected) Icons.Rounded.Groups else Icons.Outlined.Groups
        StaffTab.ESP_TERMINAL -> if (selected) Icons.Rounded.Memory else Icons.Outlined.Memory
    }

    if (tab == StaffTab.PENDING_APPROVALS && pendingCount > 0) {
        BadgedBox(
            badge = {
                Badge(
                    containerColor = colors.amberAccent,
                    contentColor = MaterialTheme.colorScheme.onTertiary
                ) {
                    Text(pendingCount.toString())
                }
            }
        ) {
            Icon(imageVector = icon, contentDescription = tab.label, modifier = Modifier.size(22.dp))
        }
    } else {
        Icon(imageVector = icon, contentDescription = tab.label, modifier = Modifier.size(22.dp))
    }
}

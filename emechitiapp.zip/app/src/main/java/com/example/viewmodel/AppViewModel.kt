package com.example.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.ApiResult
import com.example.data.AttendanceApiClient
import com.example.data.EspTapResult
import com.example.data.StaffDashboardData
import com.example.data.StaffTab
import com.example.data.TraineeDashboardData
import com.example.data.UserRole
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

sealed interface SessionScreen {
    data object Login : SessionScreen
    data object TraineeDashboard : SessionScreen
    data object StaffDashboard : SessionScreen
}

data class AppUiState(
    val screen: SessionScreen = SessionScreen.Login,

    // Login state
    val selectedRole: UserRole = UserRole.TRAINEE,
    val rollInput: String = "",
    val pinInput: String = "",
    val isLoggingIn: Boolean = false,
    val loginError: String? = null,

    // Active session credentials (in-memory only)
    val activeRoll: String = "",
    val activePin: String = "",
    val activeStaffRole: UserRole = UserRole.TRADE_INSTRUCTOR,

    // Trainee dashboard state
    val traineeData: TraineeDashboardData? = null,
    val isRefreshingTrainee: Boolean = false,
    val traineeBannerError: String? = null,
    val isSubmittingLeave: Boolean = false,
    val leaveSubmitReqId: String? = null,
    val leaveSubmitMessage: String? = null,
    val leaveSubmitError: String? = null,

    // Staff dashboard state
    val staffData: StaffDashboardData? = null,
    val selectedStaffTab: StaffTab = StaffTab.PENDING_APPROVALS,
    val isRefreshingStaff: Boolean = false,
    val staffBannerError: String? = null,

    // Staff approval state
    val signingReqId: String? = null,
    val approvalSuccessMessage: String? = null,
    val approvalPdfUrl: String? = null,
    val approvalError: String? = null,

    // Staff attendance register state
    val registerSearchQuery: String = "",
    val registerStatusFilter: String = "ALL",
    val isExportingPdf: Boolean = false,
    val exportedPdfUrl: String? = null,
    val exportPdfError: String? = null,

    // Staff ESP terminal state
    val espRollInput: String = "",
    val isTappingEsp: Boolean = false,
    val lastEspTap: EspTapResult? = null,
    val espTapHistory: List<EspTapResult> = emptyList(),
    val espTapError: String? = null
)

class AppViewModel(
    private val apiClient: AttendanceApiClient = AttendanceApiClient()
) : ViewModel() {

    private val _uiState = MutableStateFlow(AppUiState())
    val uiState: StateFlow<AppUiState> = _uiState.asStateFlow()

    fun onRoleSelected(role: UserRole) {
        _uiState.update {
            it.copy(
                selectedRole = role,
                loginError = null
            )
        }
    }

    fun onRollInputChanged(value: String) {
        val digitsOnly = value.filter { it.isDigit() }.take(2)
        _uiState.update { it.copy(rollInput = digitsOnly, loginError = null) }
    }

    fun onPinInputChanged(value: String) {
        val digitsOnly = value.filter { it.isDigit() }.take(12)
        _uiState.update { it.copy(pinInput = digitsOnly, loginError = null) }
    }

    fun login() {
        val current = _uiState.value
        if (current.isLoggingIn) return

        when (current.selectedRole) {
            UserRole.TRAINEE -> {
                val rollNum = current.rollInput.toIntOrNull()
                if (rollNum == null || rollNum !in 1..33) {
                    _uiState.update { it.copy(loginError = "Please enter a valid Roll Number between 1 and 33.") }
                    return
                }
                if (current.pinInput.isBlank()) {
                    _uiState.update { it.copy(loginError = "Please enter your Trainee PIN.") }
                    return
                }
                performTraineeLogin(rollNum.toString(), current.pinInput.trim())
            }

            UserRole.TRADE_INSTRUCTOR, UserRole.PRINCIPAL -> {
                if (current.pinInput.isBlank()) {
                    _uiState.update { it.copy(loginError = "Please enter your Staff PIN.") }
                    return
                }
                performStaffLogin(current.selectedRole, current.pinInput.trim())
            }
        }
    }

    private fun performTraineeLogin(roll: String, pin: String) {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoggingIn = true, loginError = null) }
            when (val result = apiClient.fetchTraineeData(roll = roll, pin = pin)) {
                is ApiResult.Success -> {
                    _uiState.update {
                        it.copy(
                            isLoggingIn = false,
                            screen = SessionScreen.TraineeDashboard,
                            activeRoll = roll,
                            activePin = pin,
                            traineeData = result.data,
                            traineeBannerError = null,
                            leaveSubmitReqId = null,
                            leaveSubmitMessage = null,
                            leaveSubmitError = null
                        )
                    }
                }

                is ApiResult.Error -> {
                    _uiState.update {
                        it.copy(
                            isLoggingIn = false,
                            loginError = result.message
                        )
                    }
                }
            }
        }
    }

    private fun performStaffLogin(role: UserRole, pin: String) {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoggingIn = true, loginError = null) }
            when (val result = apiClient.fetchStaffData(pin = pin)) {
                is ApiResult.Success -> {
                    _uiState.update {
                        it.copy(
                            isLoggingIn = false,
                            screen = SessionScreen.StaffDashboard,
                            activeStaffRole = role,
                            activePin = pin,
                            staffData = result.data,
                            selectedStaffTab = StaffTab.PENDING_APPROVALS,
                            staffBannerError = null,
                            approvalSuccessMessage = null,
                            approvalPdfUrl = null,
                            approvalError = null,
                            exportedPdfUrl = null,
                            exportPdfError = null,
                            lastEspTap = null,
                            espTapError = null
                        )
                    }
                }

                is ApiResult.Error -> {
                    _uiState.update {
                        it.copy(
                            isLoggingIn = false,
                            loginError = result.message
                        )
                    }
                }
            }
        }
    }

    fun refreshTraineeDashboard() {
        val current = _uiState.value
        if (current.isRefreshingTrainee || current.activeRoll.isBlank()) return
        viewModelScope.launch {
            _uiState.update { it.copy(isRefreshingTrainee = true, traineeBannerError = null) }
            when (val result = apiClient.fetchTraineeData(current.activeRoll, current.activePin)) {
                is ApiResult.Success -> {
                    _uiState.update {
                        it.copy(
                            isRefreshingTrainee = false,
                            traineeData = result.data,
                            traineeBannerError = null
                        )
                    }
                }

                is ApiResult.Error -> {
                    _uiState.update {
                        it.copy(
                            isRefreshingTrainee = false,
                            traineeBannerError = result.message
                        )
                    }
                }
            }
        }
    }

    fun submitLeaveRequest(
        type: String,
        timeWindow: String,
        reason: String,
        studentSig: String,
        onSuccessReset: () -> Unit
    ) {
        val current = _uiState.value
        if (current.isSubmittingLeave) return

        if (timeWindow.isBlank()) {
            _uiState.update { it.copy(leaveSubmitError = "Please specify a time window (e.g., 11:00 AM - 12:00 PM).") }
            return
        }
        if (reason.isBlank()) {
            _uiState.update { it.copy(leaveSubmitError = "Please enter the reason for your out-pass or leave.") }
            return
        }
        if (studentSig.isBlank()) {
            _uiState.update { it.copy(leaveSubmitError = "Please provide your digital signature before submitting.") }
            return
        }

        viewModelScope.launch {
            _uiState.update {
                it.copy(
                    isSubmittingLeave = true,
                    leaveSubmitError = null,
                    leaveSubmitMessage = null,
                    leaveSubmitReqId = null
                )
            }
            when (
                val result = apiClient.submitLeave(
                    roll = current.activeRoll,
                    pin = current.activePin,
                    type = type,
                    timeWindow = timeWindow,
                    reason = reason,
                    studentSig = studentSig
                )
            ) {
                is ApiResult.Success -> {
                    onSuccessReset()
                    _uiState.update {
                        it.copy(
                            isSubmittingLeave = false,
                            leaveSubmitReqId = result.data.reqId.ifBlank { null },
                            leaveSubmitMessage = result.data.message,
                            leaveSubmitError = null
                        )
                    }
                    refreshTraineeDashboard()
                }

                is ApiResult.Error -> {
                    _uiState.update {
                        it.copy(
                            isSubmittingLeave = false,
                            leaveSubmitError = result.message
                        )
                    }
                }
            }
        }
    }

    fun dismissLeaveFeedback() {
        _uiState.update {
            it.copy(
                leaveSubmitReqId = null,
                leaveSubmitMessage = null,
                leaveSubmitError = null
            )
        }
    }

    fun onStaffTabSelected(tab: StaffTab) {
        _uiState.update { it.copy(selectedStaffTab = tab) }
    }

    fun refreshStaffDashboard() {
        val current = _uiState.value
        if (current.isRefreshingStaff || current.activePin.isBlank()) return
        viewModelScope.launch {
            _uiState.update { it.copy(isRefreshingStaff = true, staffBannerError = null) }
            when (val result = apiClient.fetchStaffData(current.activePin)) {
                is ApiResult.Success -> {
                    _uiState.update {
                        it.copy(
                            isRefreshingStaff = false,
                            staffData = result.data,
                            staffBannerError = null
                        )
                    }
                }

                is ApiResult.Error -> {
                    _uiState.update {
                        it.copy(
                            isRefreshingStaff = false,
                            staffBannerError = result.message
                        )
                    }
                }
            }
        }
    }

    fun approveAndSignLeave(reqId: String, signature: String) {
        val current = _uiState.value
        if (current.signingReqId != null) return
        if (signature.isBlank()) {
            _uiState.update { it.copy(approvalError = "Please draw or type your digital signature before approving.") }
            return
        }

        viewModelScope.launch {
            _uiState.update {
                it.copy(
                    signingReqId = reqId,
                    approvalError = null,
                    approvalSuccessMessage = null,
                    approvalPdfUrl = null
                )
            }

            val result = if (current.activeStaffRole == UserRole.PRINCIPAL) {
                apiClient.signByPrincipal(
                    pin = current.activePin,
                    reqId = reqId,
                    principalSig = signature
                )
            } else {
                apiClient.signByInstructor(
                    pin = current.activePin,
                    reqId = reqId,
                    sirSig = signature
                )
            }

            when (result) {
                is ApiResult.Success -> {
                    _uiState.update {
                        it.copy(
                            signingReqId = null,
                            approvalSuccessMessage = result.data.message,
                            approvalPdfUrl = result.data.pdfUrl.ifBlank { null },
                            approvalError = null
                        )
                    }
                    refreshStaffDashboard()
                }

                is ApiResult.Error -> {
                    _uiState.update {
                        it.copy(
                            signingReqId = null,
                            approvalError = result.message
                        )
                    }
                }
            }
        }
    }

    fun dismissApprovalFeedback() {
        _uiState.update {
            it.copy(
                approvalSuccessMessage = null,
                approvalPdfUrl = null,
                approvalError = null
            )
        }
    }

    fun onRegisterSearchChanged(query: String) {
        _uiState.update { it.copy(registerSearchQuery = query) }
    }

    fun onRegisterStatusFilterChanged(filter: String) {
        _uiState.update { it.copy(registerStatusFilter = filter) }
    }

    fun exportDailyAttendancePdf(onPdfReady: (String) -> Unit) {
        val current = _uiState.value
        if (current.isExportingPdf) return
        viewModelScope.launch {
            _uiState.update {
                it.copy(
                    isExportingPdf = true,
                    exportPdfError = null,
                    exportedPdfUrl = null
                )
            }
            when (val result = apiClient.exportDailyAttendancePdf(current.activePin)) {
                is ApiResult.Success -> {
                    val url = result.data.pdfUrl
                    _uiState.update {
                        it.copy(
                            isExportingPdf = false,
                            exportedPdfUrl = url.ifBlank { null },
                            exportPdfError = if (url.isBlank()) "Server did not return a PDF link." else null
                        )
                    }
                    if (url.isNotBlank()) {
                        onPdfReady(url)
                    }
                }

                is ApiResult.Error -> {
                    _uiState.update {
                        it.copy(
                            isExportingPdf = false,
                            exportPdfError = result.message
                        )
                    }
                }
            }
        }
    }

    fun onEspRollInputChanged(value: String) {
        val digitsOnly = value.filter { it.isDigit() }.take(2)
        _uiState.update { it.copy(espRollInput = digitsOnly, espTapError = null) }
    }

    fun triggerManualEspTap() {
        val current = _uiState.value
        if (current.isTappingEsp) return
        val rollNum = current.espRollInput.toIntOrNull()
        if (rollNum == null || rollNum !in 1..33) {
            _uiState.update { it.copy(espTapError = "Enter a valid trainee Roll Number (1–33).") }
            return
        }

        viewModelScope.launch {
            _uiState.update { it.copy(isTappingEsp = true, espTapError = null) }
            when (val result = apiClient.triggerEspTap(rollNum.toString())) {
                is ApiResult.Success -> {
                    _uiState.update { state ->
                        state.copy(
                            isTappingEsp = false,
                            lastEspTap = result.data,
                            espTapHistory = listOf(result.data) + state.espTapHistory.take(9),
                            espTapError = null
                        )
                    }
                    // Refresh attendance register so the live punch appears immediately
                    refreshStaffDashboard()
                }

                is ApiResult.Error -> {
                    _uiState.update {
                        it.copy(
                            isTappingEsp = false,
                            espTapError = result.message
                        )
                    }
                }
            }
        }
    }

    fun logout() {
        _uiState.update {
            AppUiState(
                selectedRole = it.selectedRole
            )
        }
    }
}

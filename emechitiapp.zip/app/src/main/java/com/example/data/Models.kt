package com.example.data

enum class UserRole(val displayName: String) {
    TRAINEE("Trainee"),
    TRADE_INSTRUCTOR("Trade Instructor"),
    PRINCIPAL("Principal")
}

enum class StaffTab(val label: String) {
    PENDING_APPROVALS("Approvals"),
    ATTENDANCE_REGISTER("Register"),
    ESP_TERMINAL("ESP Punch")
}

data class AttendanceSummary(
    val todayStatus: String,
    val inT: String,
    val outT: String,
    val present: Int,
    val half: Int,
    val total: Int,
    val pct: Int
)

data class TraineeLeaveItem(
    val id: String,
    val date: String,
    val type: String,
    val status: String,
    val pdf: String
)

data class TraineeDashboardData(
    val roll: String,
    val name: String,
    val attendance: AttendanceSummary,
    val leaves: List<TraineeLeaveItem>
)

data class StaffAttendanceRecord(
    val roll: String,
    val name: String,
    val todayStatus: String,
    val inT: String,
    val outT: String,
    val present: Int,
    val half: Int,
    val total: Int,
    val pct: Int
)

data class PendingLeaveRequest(
    val reqId: String,
    val date: String,
    val roll: String,
    val name: String,
    val type: String,
    val timeWindow: String,
    val reason: String
)

data class StaffDashboardData(
    val allAttendance: List<StaffAttendanceRecord>,
    val pendingLeaves: List<PendingLeaveRequest>
)

data class LeaveSubmitResult(
    val reqId: String,
    val message: String
)

data class SignApprovalResult(
    val reqId: String,
    val message: String,
    val pdfUrl: String
)

data class PdfExportResult(
    val pdfUrl: String,
    val message: String
)

data class EspTapResult(
    val roll: String,
    val mode: String,
    val name: String,
    val time: String,
    val message: String
)

sealed class ApiResult<out T> {
    data class Success<T>(val data: T) : ApiResult<T>()
    data class Error(val message: String) : ApiResult<Nothing>()
}

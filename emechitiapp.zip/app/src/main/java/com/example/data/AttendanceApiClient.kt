package com.example.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit
import kotlin.math.roundToInt

class AttendanceApiClient {

    companion object {
        const val BASE_URL =
            "https://script.google.com/macros/s/AKfycbyHV65ckL_FdhXCd27TTCxJbgMY5tc0d8Pvifxe60o7aLMe0TMvjzuknotjEvwoDOzRyw/exec"
        const val ESP_KEY = "EMECH_KEY_2026"
    }

    private val client: OkHttpClient = OkHttpClient.Builder()
        .followRedirects(true)
        .followSslRedirects(true)
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(35, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    suspend fun fetchTraineeData(roll: String, pin: String): ApiResult<TraineeDashboardData> {
        return executeGet(
            mapOf(
                "action" to "trainee_data",
                "roll" to roll.trim(),
                "pin" to pin.trim()
            )
        ) { json ->
            val name = json.optString("name", "Trainee #$roll").ifBlank { "Trainee #$roll" }
            val attObj = json.optJSONObject("attendance") ?: JSONObject()
            val attendance = AttendanceSummary(
                todayStatus = attObj.optString("todayStatus", "ABSENT").ifBlank { "ABSENT" },
                inT = attObj.optString("inT", "-").ifBlank { "-" },
                outT = attObj.optString("outT", "-").ifBlank { "-" },
                present = attObj.optSafeInt("present"),
                half = attObj.optSafeInt("half"),
                total = attObj.optSafeInt("total"),
                pct = attObj.optSafeInt("pct")
            )

            val leavesArray = json.optJSONArray("leaves") ?: JSONArray()
            val leaves = buildList {
                for (i in 0 until leavesArray.length()) {
                    val item = leavesArray.optJSONObject(i) ?: continue
                    add(
                        TraineeLeaveItem(
                            id = item.optString("id", item.optString("reqId", "")),
                            date = item.optString("date", "-"),
                            type = item.optString("type", "Out-Pass"),
                            status = item.optString("status", "PENDING_SIR"),
                            pdf = item.optString("pdf", item.optString("pdfUrl", "")).trim()
                        )
                    )
                }
            }

            TraineeDashboardData(
                roll = roll.trim(),
                name = name,
                attendance = attendance,
                leaves = leaves
            )
        }
    }

    suspend fun submitLeave(
        roll: String,
        pin: String,
        type: String,
        timeWindow: String,
        reason: String,
        studentSig: String
    ): ApiResult<LeaveSubmitResult> {
        return executeGet(
            mapOf(
                "action" to "submit_leave",
                "roll" to roll.trim(),
                "pin" to pin.trim(),
                "type" to type.trim(),
                "timeWindow" to timeWindow.trim(),
                "reason" to reason.trim(),
                "studentSig" to studentSig.trim()
            )
        ) { json ->
            val reqId = json.optString("reqId", json.optString("id", "")).trim()
            val msg = json.optString("msg", "Out-pass request submitted successfully.").ifBlank {
                "Out-pass request submitted successfully."
            }
            LeaveSubmitResult(reqId = reqId, message = msg)
        }
    }

    suspend fun fetchStaffData(pin: String): ApiResult<StaffDashboardData> {
        return executeGet(
            mapOf(
                "action" to "staff_data",
                "pin" to pin.trim()
            )
        ) { json ->
            val attArray = json.optJSONArray("allAttendance") ?: JSONArray()
            val attendanceList = buildList {
                for (i in 0 until attArray.length()) {
                    val item = attArray.optJSONObject(i) ?: continue
                    add(
                        StaffAttendanceRecord(
                            roll = item.optSafeString("roll"),
                            name = item.optString("name", "Unknown Trainee"),
                            todayStatus = item.optString("todayStatus", "ABSENT").ifBlank { "ABSENT" },
                            inT = item.optString("inT", "-").ifBlank { "-" },
                            outT = item.optString("outT", "-").ifBlank { "-" },
                            present = item.optSafeInt("present"),
                            half = item.optSafeInt("half"),
                            total = item.optSafeInt("total"),
                            pct = item.optSafeInt("pct")
                        )
                    )
                }
            }

            val pendingArray = json.optJSONArray("pendingLeaves") ?: JSONArray()
            val pendingList = buildList {
                for (i in 0 until pendingArray.length()) {
                    val item = pendingArray.optJSONObject(i) ?: continue
                    add(
                        PendingLeaveRequest(
                            reqId = item.optString("reqId", item.optString("id", "")),
                            date = item.optString("date", "-"),
                            roll = item.optSafeString("roll"),
                            name = item.optString("name", "Trainee"),
                            type = item.optString("type", "Out-Pass"),
                            timeWindow = item.optString("timeWindow", "-"),
                            reason = item.optString("reason", "-")
                        )
                    )
                }
            }

            StaffDashboardData(
                allAttendance = attendanceList,
                pendingLeaves = pendingList
            )
        }
    }

    suspend fun signByInstructor(
        pin: String,
        reqId: String,
        sirSig: String
    ): ApiResult<SignApprovalResult> {
        return executeGet(
            mapOf(
                "action" to "sign_sir",
                "pin" to pin.trim(),
                "reqId" to reqId.trim(),
                "sirSig" to sirSig.trim()
            )
        ) { json ->
            SignApprovalResult(
                reqId = reqId,
                message = json.optString("msg", "Approved by Trade Instructor.").ifBlank {
                    "Approved by Trade Instructor."
                },
                pdfUrl = json.optString("pdfUrl", json.optString("pdf", "")).trim()
            )
        }
    }

    suspend fun signByPrincipal(
        pin: String,
        reqId: String,
        principalSig: String
    ): ApiResult<SignApprovalResult> {
        return executeGet(
            mapOf(
                "action" to "sign_principal",
                "pin" to pin.trim(),
                "reqId" to reqId.trim(),
                "principalSig" to principalSig.trim()
            )
        ) { json ->
            SignApprovalResult(
                reqId = reqId,
                message = json.optString("msg", "Approved & Signed by Principal.").ifBlank {
                    "Approved & Signed by Principal."
                },
                pdfUrl = json.optString("pdfUrl", json.optString("pdf", "")).trim()
            )
        }
    }

    suspend fun exportDailyAttendancePdf(pin: String): ApiResult<PdfExportResult> {
        return executeGet(
            mapOf(
                "action" to "print_attendance",
                "pin" to pin.trim()
            )
        ) { json ->
            val pdfUrl = json.optString("pdfUrl", json.optString("pdf", "")).trim()
            val msg = json.optString("msg", "Daily Attendance PDF generated.").ifBlank {
                "Daily Attendance PDF generated."
            }
            PdfExportResult(pdfUrl = pdfUrl, message = msg)
        }
    }

    suspend fun triggerEspTap(roll: String): ApiResult<EspTapResult> {
        return executeGet(
            mapOf(
                "action" to "tap",
                "key" to ESP_KEY,
                "roll" to roll.trim()
            )
        ) { json ->
            EspTapResult(
                roll = roll.trim(),
                mode = json.optString("mode", "PRESENT").ifBlank { "PRESENT" },
                name = json.optString("name", "Roll #$roll").ifBlank { "Roll #$roll" },
                time = json.optString("time", "-").ifBlank { "-" },
                message = json.optString("msg", "").trim()
            )
        }
    }

    private suspend fun <T> executeGet(
        params: Map<String, String>,
        parser: (JSONObject) -> T
    ): ApiResult<T> = withContext(Dispatchers.IO) {
        try {
            val urlBuilder = BASE_URL.toHttpUrl().newBuilder()
            params.forEach { (key, value) ->
                urlBuilder.addQueryParameter(key, value)
            }
            val request = Request.Builder()
                .url(urlBuilder.build())
                .get()
                .header("Accept", "application/json")
                .build()

            client.newCall(request).execute().use { response ->
                val rawBody = response.body?.string()?.trim().orEmpty()
                if (!response.isSuccessful) {
                    return@withContext ApiResult.Error(
                        "Server responded with HTTP ${response.code}. Please try again."
                    )
                }
                if (rawBody.isEmpty()) {
                    return@withContext ApiResult.Error(
                        "Empty response received from Attendance Server."
                    )
                }
                if (!rawBody.startsWith("{")) {
                    return@withContext ApiResult.Error(
                        "Unexpected response format from server. Please check network or script deployment."
                    )
                }

                val json = JSONObject(rawBody)
                val ok = json.optBoolean("ok", false)
                if (!ok) {
                    val errorMsg = json.optString("msg", "")
                        .ifBlank { json.optString("error", "") }
                        .ifBlank { "Request could not be completed. Please verify credentials." }
                    return@withContext ApiResult.Error(errorMsg)
                }

                ApiResult.Success(parser(json))
            }
        } catch (e: IOException) {
            ApiResult.Error("Network error: Unable to reach Govt. ITI Ranni server. Check internet connection.")
        } catch (e: Exception) {
            ApiResult.Error(e.localizedMessage ?: "An unexpected error occurred while communicating with the server.")
        }
    }

    private fun JSONObject.optSafeInt(key: String, default: Int = 0): Int {
        if (!has(key) || isNull(key)) return default
        val raw = opt(key)
        return when (raw) {
            is Number -> raw.toDouble().roundToInt()
            is String -> raw.trim().toDoubleOrNull()?.roundToInt() ?: default
            else -> default
        }
    }

    private fun JSONObject.optSafeString(key: String, default: String = ""): String {
        if (!has(key) || isNull(key)) return default
        val raw = opt(key)
        return raw?.toString()?.trim()?.ifBlank { default } ?: default
    }
}

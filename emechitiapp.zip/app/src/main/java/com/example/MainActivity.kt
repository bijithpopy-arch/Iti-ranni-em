package com.example

import android.graphics.Color
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.screens.LoginScreen
import com.example.ui.screens.StaffDashboardScreen
import com.example.ui.screens.TraineeDashboardScreen
import com.example.ui.theme.ItiRanniTheme
import com.example.viewmodel.AppViewModel
import com.example.viewmodel.SessionScreen

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(Color.TRANSPARENT)
        )
        setContent {
            ItiRanniTheme {
                ItiAttendanceApp()
            }
        }
    }
}

@Composable
fun ItiAttendanceApp(
    viewModel: AppViewModel = viewModel()
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()

    Crossfade(
        targetState = uiState.screen,
        animationSpec = tween(durationMillis = 240),
        label = "session_screen_transition",
        modifier = Modifier.fillMaxSize()
    ) { screen ->
        when (screen) {
            SessionScreen.Login -> LoginScreen(
                uiState = uiState,
                onRoleSelected = viewModel::onRoleSelected,
                onRollChanged = viewModel::onRollInputChanged,
                onPinChanged = viewModel::onPinInputChanged,
                onLoginClick = viewModel::login
            )

            SessionScreen.TraineeDashboard -> TraineeDashboardScreen(
                uiState = uiState,
                onRefresh = viewModel::refreshTraineeDashboard,
                onLogout = viewModel::logout,
                onSubmitLeave = viewModel::submitLeaveRequest,
                onDismissFeedback = viewModel::dismissLeaveFeedback
            )

            SessionScreen.StaffDashboard -> StaffDashboardScreen(
                uiState = uiState,
                onTabSelected = viewModel::onStaffTabSelected,
                onRefresh = viewModel::refreshStaffDashboard,
                onLogout = viewModel::logout,
                onApproveAndSign = viewModel::approveAndSignLeave,
                onDismissApprovalFeedback = viewModel::dismissApprovalFeedback,
                onRegisterSearchChanged = viewModel::onRegisterSearchChanged,
                onRegisterStatusFilterChanged = viewModel::onRegisterStatusFilterChanged,
                onExportPdf = viewModel::exportDailyAttendancePdf,
                onEspRollChanged = viewModel::onEspRollInputChanged,
                onTriggerManualTap = viewModel::triggerManualEspTap
            )
        }
    }
}
